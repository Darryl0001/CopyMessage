import React, { useEffect, useState } from "react";

const Message = ({ message }) => {
  const [revealedMessages, setRevealedMessages] = useState([]);

  useEffect(() => {
    let timeouts = [];
    let timer = 0;

    message.forEach(([msg, delay]) => {
      timer += delay * 1000; 
      const timeout = setTimeout(() => {
        setRevealedMessages((prevMessages) => [...prevMessages, msg]);
      }, timer);
      timeouts.push(timeout); // Store each timeout ID
    });

    // Cleanup all timeouts when the component is unmounted or message changes
    return () => {
      timeouts.forEach((timeout) => clearTimeout(timeout));
    };
  }, [message]);

  return (
    <div className="message-list">
      {revealedMessages.map((msg, index) => (
        <div key={index} className="message">
          {msg}
        </div>
      ))}
    </div>
  );
};

export default Message;
