import React, { useState, useEffect } from "react";

const First = ({setdisableBtn}) => {
  const messages = [
    { msg: "I have something to tell you...", delay: 0.3 }, 
  ];

  const [visibleMessages, setVisibleMessages] = useState([]);

  useEffect(() => {
    messages.forEach(({ msg, delay }) => {
      setTimeout(() => {
        setVisibleMessages((prev) => [...prev, msg]);
      }, delay * 1000);
    });
  }, []);

  const revealStyles = {
    opacity: '1',
    visibility: 'visible',
    transition: 'opacity 0.3s ease-in',
  };
  useEffect(() => {
      setTimeout(() => {
        setdisableBtn(false);
      }, 0.4 * 1000);
  }, []);
  
  return (
    <div className="message-list">
      {messages.map((m, index) => (
        <div
          key={index}
          className="message"
          style={visibleMessages.includes(m.msg) ? revealStyles : { opacity: '0', visibility: 'hidden' }}
        >
          {m.msg}
        </div>
      ))}
    </div>
  );
};

export default First;
