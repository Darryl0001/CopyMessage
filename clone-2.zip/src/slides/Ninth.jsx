import React, { useState, useEffect } from "react";
import Heart from '../design/Heart.jsx'
import Image from '../design/Image.jsx'

const Ninth = ({setdisableBtn}) => {
  const messages = [
    { 
      msg: "My question is...",
      delay: 0.3,
    }, 
    { 
      msg: "Would it be okay if I started pursuing you with respect and intention?",
      delay: 1.4,
      style: {
        fontSize: '1.4rem',
        fontWeight:'bold',
        textAlign:'middle'
      },
    }, 
    { 
      msg: '"Take your time to answer this... no pressure.',
      delay: 2.7
    }
  ];
  /*
  useEffect(() => {
    const timer = setTimeout(() => {
      setdisableBtn(false);
    }, 4.9
    * 1000);

    return () => clearTimeout(timer); // Cleanup timer
  }, [setdisableBtn]);
*/

  
  
  const [visibleMessages, setVisibleMessages] = useState([]);

  useEffect(() => {
    messages.forEach(({ msg, delay }) => {
      setTimeout(() => {
        setVisibleMessages((prev) => [...prev, msg]);
      }, delay * 1000);
    });
  }, [messages]);
  
  const revealStyles = {
    opacity: '1',
    visibility: 'visible',
    transition: 'opacity 0.3s ease-in',
  };

  const hiddenStyles = {
    opacity: '0',
    visibility: 'hidden',
  };

  return (
    <div className="message-list"
    style= {
      {
        backgroundColor:'transparent'
      }
    }
    
    >
    
      {messages.map((m, index) => (
        <div
          key={index}
          className="message"
          style={{
            ...(visibleMessages.includes(m.msg) ? revealStyles : hiddenStyles),
            ...(m.style || {}),
          }}
        >
          {m.msg}
        </div>
      ))}
     
<div style={{ display: 'flex', justifyContent: 'center', padding: '10px' }}>
      <iframe
        src="https://docs.google.com/forms/d/e/1FAIpQLSdxQxpXDdn9DnyHbmwSlnMe9UzxcsCyyjL_ebEaLsLNGFdl_A/viewform?embedded=true"
        style={{
          width: '100%',
          maxWidth: '600px', 
          height: '70vh', 
          border: 'none'
        }}
        frameBorder="0"
        marginHeight="0"
        marginWidth="0"
        title="Google Form"
      >
        Loading…
      </iframe>
    </div>
    </div>
  );
};

export default Ninth;
