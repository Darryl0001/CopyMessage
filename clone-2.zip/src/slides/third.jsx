import React, { useState, useEffect } from "react";
import Heart from '../design/Heart.jsx'
import Image from '../design/Image.jsx'

const Third = ({setdisableBtn}) => {
  const messages = [
    { 
      msg: "Asa ra gud ng kakapoy",
      delay: 0.3,
    }, 
    { 
      msg: "Ug ikaw permi akong gipangandoy...",
      delay: 1.2,
      style: {
        fontSize: '1.4rem',
        fontWeight:'bold',
        textAlign:'right'
      },
    }, 
    { 
      msg: "Kabantay ka kusog kaayung ulan???",
      delay: 2,
    }, 
    { 
      msg: "Pero murag waka kabantay nga ikaw ang gipitik ning akong dughan :('",
      delay: 2.7,
      style: {

        fontWeight:'bold',
      }
    }, 
  ];
  useEffect(() => {
    const timer = setTimeout(() => {
      setdisableBtn(false);
    }, 4.2 * 1000);

    return () => clearTimeout(timer); // Cleanup timer
  }, [setdisableBtn]);


  useEffect(() => {
    const timer = setTimeout(() => {
      document.body.style.backgroundColor = "pink";
    }, 0.3 * 1000);

    return () => {
      clearTimeout(timer); // Cleanup timer
      
    };
  }, []);
  
  const [visibleMessages, setVisibleMessages] = useState([]);

  useEffect(() => {
    messages.forEach(({ msg, delay }) => {
      setTimeout(() => {
        setVisibleMessages((prev) => [...prev, msg]);
      }, delay * 1000);
    });
  }, [messages]);
  
  const revealStyles = {
    opacity: '1',
    visibility: 'visible',
    transition: 'opacity 0.3s ease-in',
  };

  const hiddenStyles = {
    opacity: '0',
    visibility: 'hidden',
  };

  return (
    <div className="message-list"
    style= {
      {
        backgroundColor:'transparent'
      }
    }
    
    >
    
      {messages.map((m, index) => (
        <div
          key={index}
          className="message"
          style={{
            ...(visibleMessages.includes(m.msg) ? revealStyles : hiddenStyles),
            ...(m.style || {}),
          }}
        >
          {m.msg}
        </div>
      ))}
     
     <Image imgSource ={"https://www.facebook.com/c3fe7a25-7d4d-4bd7-8166-5f8df1366d5a"}
     delay = {4.2}
     />
    </div>
  );
};

export default Third;
