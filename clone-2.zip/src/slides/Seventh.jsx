import React, { useState, useEffect } from "react";
import Heart from '../design/Heart.jsx'
import Image from '../design/Image.jsx'

const Seventh = ({setdisableBtn}) => {
  const messages = [
    { 
      msg: "You know what I like you the most?",
      delay: 0.3,
    }, 
    { 
      msg: "Coz you're like Proverbs 31:30 that says",
      delay: 1.4,
    }, 
    { 
      msg: '"Charm is deceptive, and beauty is fleeting, but a woman who fears the Lord is to be praised."',
      delay: 2.7,
      style: {
        fontSize: '1.3rem',
        fontWeight:'bold',
        textAlign:'right'
      },
    }, 
    { 
      msg: "And in verse 10,",
      delay: 4,
      style: {
      }
    },
    { 
      msg: "She is more precious than",
      delay: 4.4,
      style: {
        fontSize: '1.3rem',
        fontWeight:'bold',
        textAlign:'right'
      },
    }, 
    { 
      msg: "RUBIES.",
      delay: 4.8,
      style: {
        fontSize: '2.4rem',
        fontWeight:'bold',
        color:'red',
        textAlign:'right'
      },
    }, 
  ];
  useEffect(() => {
    const timer = setTimeout(() => {
      setdisableBtn(false);
    }, 4.9
    * 1000);

    return () => clearTimeout(timer); // Cleanup timer
  }, [setdisableBtn]);


  useEffect(() => {
    const timer = setTimeout(() => {
      document.body.style.backgroundColor = "white";
      
    }, 0.3 * 1000);

    return () => {
      clearTimeout(timer); // Cleanup timer
      
    };
  }, []);
  
  const [visibleMessages, setVisibleMessages] = useState([]);

  useEffect(() => {
    messages.forEach(({ msg, delay }) => {
      setTimeout(() => {
        setVisibleMessages((prev) => [...prev, msg]);
      }, delay * 1000);
    });
  }, [messages]);
  
  const revealStyles = {
    opacity: '1',
    visibility: 'visible',
    transition: 'opacity 0.3s ease-in',
  };

  const hiddenStyles = {
    opacity: '0',
    visibility: 'hidden',
  };

  return (
    <div className="message-list"
    style= {
      {
        backgroundColor:'transparent'
      }
    }
    
    >
    
      {messages.map((m, index) => (
        <div
          key={index}
          className="message"
          style={{
            ...(visibleMessages.includes(m.msg) ? revealStyles : hiddenStyles),
            ...(m.style || {}),
          }}
        >
          {m.msg}
        </div>
      ))}
     
    </div>
  );
};

export default Seventh;
