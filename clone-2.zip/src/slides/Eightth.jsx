import React, { useState, useEffect } from "react";
import Heart from '../design/Heart.jsx'
import Image from '../design/Image.jsx'

const Eigthth = ({setdisableBtn}) => {
  const messages = [
    { 
      msg: "You remind me of that verse because of the kindness and faith you show.",
      delay: 0.3,
    }, 
    { 
      msg: "I truly admire your heart, and I believe God places people in our lives for a reason.",
      delay: 1.7,
    }, 
    { 
      msg: "I would like to get to know you more and see where this could lead, with God's guidance.",
      delay: 3,
      
    }, 
  ];
  useEffect(() => {
    const timer = setTimeout(() => {
      setdisableBtn(false);
    }, 3.4 * 1000);

    return () => clearTimeout(timer); // Cleanup timer
  }, [setdisableBtn]);

  
  const [visibleMessages, setVisibleMessages] = useState([]);

  useEffect(() => {
    messages.forEach(({ msg, delay }) => {
      setTimeout(() => {
        setVisibleMessages((prev) => [...prev, msg]);
      }, delay * 1000);
    });
  }, [messages]);
  
  const revealStyles = {
    opacity: '1',
    visibility: 'visible',
    transition: 'opacity 0.3s ease-in',
  };

  const hiddenStyles = {
    opacity: '0',
    visibility: 'hidden',
  };

  return (
    <div className="message-list"
    style= {
      {
        backgroundColor:'transparent'
      }
    }
    
    >
    
      {messages.map((m, index) => (
        <div
          key={index}
          className="message"
          style={{
            ...(visibleMessages.includes(m.msg) ? revealStyles : hiddenStyles),
            ...(m.style || {}),
          }}
        >
          {m.msg}
        </div>
      ))}
     
    </div>
  );
};

export default Eigthth;
