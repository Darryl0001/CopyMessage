import React, { useState, useEffect } from "react";
import Heart from '../design/Heart.jsx'
import Image from '../design/Image.jsx'

const Fourth = ({setdisableBtn}) => {
  const messages = [
    { 
      msg: "Sugot ka imoha nanang milo???",
      delay: 0.3,
    }, 
    { 
      msg: "Pero ako naka everyday",
      delay: 1.2,
      style: {
        fontSize: '1.4rem',
        fontWeight:'bold',
        marginBottom:'1.5rem',
        textAlign:'right'
      },
    }, 
    { 
      msg: "Pero ayawg kabalaka kay ang akong gugma",
      delay: 2.4,
    },
        { 
      msg: "NAA RA KANIMO <3",
      delay: 3,
      style: {
        fontSize: '1.8rem',
        fontWeight:'bold',
      },
    }
  ];

  const [visibleMessages, setVisibleMessages] = useState([]);

  useEffect(() => {
    messages.forEach(({ msg, delay }) => {
      setTimeout(() => {
        setVisibleMessages((prev) => [...prev, msg]);
      }, delay * 1000);
    });
  }, [messages]);
  
  useEffect(() => {
    const timer = setTimeout(() => {
      setdisableBtn(false);
    }, 4.2 * 1000);

    return () => clearTimeout(timer); // Cleanup timer
  }, [setdisableBtn]);
  
  const revealStyles = {
    opacity: '1',
    visibility: 'visible',
    transition: 'opacity 0.3s ease-in',
  };

  const hiddenStyles = {
    opacity: '0',
    visibility: 'hidden',
  };

  return (
    <div className="message-list"
    style= {
      {
        backgroundColor:'transparent'
      }
    }
    
    >
    
      {messages.map((m, index) => (
        <div
          key={index}
          className="message"
          style={{
            ...(visibleMessages.includes(m.msg) ? revealStyles : hiddenStyles),
            ...(m.style || {}),
          }}
        >
          {m.msg}
        </div>
      ))}

     <Image imgSource ={"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTpejE8OVI_HRouPXZFjv2ZASZrmsAbt_xzxbwJmxEotATgmuYo_2nSI4I&s=10"}
     delay = {3.1}
     />
    </div>
  );
};

export default Fourth;
