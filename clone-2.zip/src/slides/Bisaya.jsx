import Third from "./third.jsx";
import React, { useState, useEffect } from "react";
import Fourth from "./Fourth.jsx"; 

const Bisaya = ({ setdisableBtn }) => {
  const [nextJoke, setNextJoke] = useState(0);

  const handleNextJoke = () => {
    if (nextJoke < JokePages.length - 1) {
      setNextJoke((c) => c + 1); // Simplified increment logic
    }
  };

  useEffect(() => {
    const timer = setTimeout(() => {
      setdisableBtn(false);
    }, 4.2 * 1000);

    return () => clearTimeout(timer); // Cleanup timer
  }, [setdisableBtn]);

  // Change background color with smooth transition
  useEffect(() => {
    const timer = setTimeout(() => {
      document.body.style.backgroundColor = "pink";
    }, 0.3 * 1000);

    return () => {
      clearTimeout(timer); // Cleanup timer
      document.body.style.backgroundColor = ""; // Reset background
    };
  }, []);
  
  const JokePages = [
    <Third handleNextJoke={handleNextJoke} />, 
    <Fourth handleNextJoke={handleNextJoke} />, 
        <Fourth handleNextJoke={handleNextJoke} />
  ];

  return <>{JokePages[nextJoke]}</>;
};

export default Bisaya;
