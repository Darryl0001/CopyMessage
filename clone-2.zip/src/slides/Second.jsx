import React, { useState, useEffect } from "react";
import Heart from '../design/Heart.jsx'


const Second = ({setdisableBtn}) => {
  const messages = [
    { 
      msg: "Hiii Jamaica/memet ...",
      delay: 0.4,
    }, 
    { 
      msg: "I want to share something from my heart.",
      delay: 1,
      style: {
        fontSize: '2rem',
        fontWeight:'bold'
      },
    }, 
  ];

  const [visibleMessages, setVisibleMessages] = useState([]);

  useEffect(() => {
    messages.forEach(({ msg, delay }) => {
      setTimeout(() => {
        setVisibleMessages((prev) => [...prev, msg]);
      }, delay * 1000);
    });
  }, [messages]);
  useEffect(() => {
      setTimeout(() => {
        setdisableBtn(false);
      }, 1.5 * 1000);
  }, []);
  
  
  
  const revealStyles = {
    opacity: '1',
    visibility: 'visible',
    transition: 'opacity 0.3s ease-in',
  };

  const hiddenStyles = {
    opacity: '0',
    visibility: 'hidden',
  };

  return (
    <div className="message-list">
      {messages.map((m, index) => (
        <div
          key={index}
          className="message"
          style={{
            ...(visibleMessages.includes(m.msg) ? revealStyles : hiddenStyles),
            ...(m.style || {}),
          }}
        >
          {m.msg}
        </div>
      ))}
      <Heart delay = {1.5} />
    </div>
  );
};

export default Second;
