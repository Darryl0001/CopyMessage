import React, { useEffect, useState } from "react";
//import './Message.css'; // Make sure you have the transition styles here

const Message = ({ message }) => {
  const [revealedMessages, setRevealedMessages] = useState([]);

  useEffect(() => {
    let timer = 0;
    setRevealedMessages([]); // Clear the previous messages when the component rerenders

    message.forEach(([msg, delay]) => {
      timer += delay * 1000;
      setTimeout(() => {
        setRevealedMessages((prevMessages) => [...prevMessages, msg]);
      }, timer);
    });

    return () => clearTimeout(timer);
  }, [message]);

  return (
    <div className="message-list">
      {revealedMessages.map((msg, index) => (
        <div key={index} className="message show">
          {msg}
        </div>
      ))}
    </div>
  );
};

export default Message;
