import React, { useState, useEffect } from "react";
import "./heart.css";

const Images = ({ delay = 0, imgSource }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, delay * 1000);

    return () => clearTimeout(timer); // Cleanup the timer
  }, [delay]);

  // Ensure imgSource is passed and is a valid string
  if (!imgSource) {
    console.error("No image source provided!");
    return null;
  }

  return (
    <img
      className="img1"
      style={{
        visibility: isVisible ? "visible" : "hidden",
        transition: "visibility 0s, opacity 0.5s ease-in-out", // Smooth fade-in
        opacity: isVisible ? 1 : 0, // Smooth fade-in effect
      }}
      src={imgSource}
      
    />
  );
};

export default Images;
