
import React, { useState, useEffect } from "react";
import "./heart.css";

const Heart = ({ delay = 0, size = 3 }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsVisible(true);
    }, delay * 1000);

    return () => clearTimeout(timer); // Cleanup the timer
  }, [delay]);

  // Ensure size is passed as a number, default to 3 if invalid
  

  return (
    <div
      className="heart"
      style={{
        visibility: isVisible ? "visible" : "hidden"
      }}
    ></div>
  );
};

export default Heart;
