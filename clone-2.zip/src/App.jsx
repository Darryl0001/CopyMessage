import React, { useState } from "react";
import "./App.css";
import First from './slides/First.jsx';
import Second from './slides/Second.jsx';
import Third from './slides/third.jsx';
//import Bisaya from './slides/Bisaya.jsx';
import Fourth from './slides/Fourth.jsx';
import Fifth from './slides/Fifth.jsx';
import Sixth from './slides/Sixth.jsx';
import Seventh from './slides/Seventh.jsx';
import Eigthth from './slides/Eightth.jsx'; 
import Ninth from './slides/Ninth.jsx'; 


function App() {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [disableBtn, setdisableBtn] = useState(true)
  
  const nextMessage = () => {
    if (currentIndex < Slides.length - 1) {
      setCurrentIndex((prevIndex) => prevIndex + 1);
      setdisableBtn(true)
    }
  };

  const prevMessage = () => {
    if (currentIndex > 0) {
      setCurrentIndex((prevIndex) => prevIndex - 1);
      setdisableBtn(true)
    }
  };


  // Slides array containing components
  const Slides = [
    { component: <First setdisableBtn={setdisableBtn}/>,
      name: "First Slide" },
    { component: <Second setdisableBtn={setdisableBtn}/>,
      name: "Second Slide" },
    { component: <Third setdisableBtn={setdisableBtn}/>,
      name: "Third Slide" },
    { component: <Fourth setdisableBtn={setdisableBtn}/>,
      name: "Fourth Slide" },
    { component: <Fifth setdisableBtn={setdisableBtn}/>,
      name: "Fifth Slide" },
    { component: <Sixth setdisableBtn={setdisableBtn}/>,
      name: "Sixth Slide" },
    { component: <Seventh setdisableBtn={setdisableBtn}/>,
      name: "Seventh Slide" },
    { component: <Eigthth setdisableBtn={setdisableBtn}/>,
      name: "Eightth Slide" },
    { component: <Ninth setdisableBtn={setdisableBtn}/>,
      name: "Ninth Slide" },
  ];

  return (
    <div className="app">
      <button
        onClick={prevMessage}
        className="btn prev-btn"
        disabled={currentIndex === 0  || disableBtn}
        aria-label="Previous Slide"
      >
        ↑
      </button>

      <div className="message-container" aria-live="polite">
        {Slides[currentIndex].component}
      </div>

      <button
        onClick={nextMessage}
        className="btn next-btn"
        disabled={currentIndex === Slides.length - 1 || disableBtn}
        aria-label="Next Slide"
      >
        ↓
      </button>
    </div>
  );
}

export default App;
